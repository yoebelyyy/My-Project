<?php
/* ============================================================
   FILE: modules/save_quiz_result.php
   Purpose: Save quiz score + convert points to relief goods
   ============================================================ */

require_once '../db_connect.php';
header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Not logged in']);
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$score   = max(0, (int)($_POST['score']   ?? 0));
$correct = max(0, (int)($_POST['correct'] ?? 0));
$total   = max(0, (int)($_POST['total']   ?? 0));

/* Points → Relief goods (100 pts = 1 good) */
$goodsEarned = (int)floor($score / 100);

/* ---- Save to quiz_results if table exists ---- */
$tbl = mysqli_query($conn, "SHOW TABLES LIKE 'quiz_results'");
if ($tbl && mysqli_num_rows($tbl) > 0) {
    $stmt = mysqli_prepare($conn,
        "INSERT INTO quiz_results (user_id, score, correct_count, total_questions, completed_at)
         VALUES (?, ?, ?, ?, NOW())");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'iiii', $user_id, $score, $correct, $total);
        mysqli_stmt_execute($stmt);
    }
}

/* ---- Add points to users.quiz_score ---- */
mysqli_query($conn,
    "UPDATE users SET quiz_score = quiz_score + $score WHERE id = $user_id");

/* ---- Store relief goods in users table if column exists ---- */
$colCheck = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'relief_goods'");
if ($colCheck && mysqli_num_rows($colCheck) > 0 && $goodsEarned > 0) {
    mysqli_query($conn,
        "UPDATE users SET relief_goods = relief_goods + $goodsEarned WHERE id = $user_id");
}

echo json_encode([
    'ok'     => true,
    'score'  => $score,
    'correct'=> $correct,
    'goods'  => $goodsEarned
]);