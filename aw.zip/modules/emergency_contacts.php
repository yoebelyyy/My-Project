<?php
require_once '../db_connect.php';
if (!isLoggedIn()) redirect('login.php');

$user_id = (int)$_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id"));
if (!$user) { session_destroy(); redirect('login.php'); }

$is_admin = (isset($user['role']) && strtolower($user['role']) === 'admin');

/* ============================================================
   Fetch emergency contacts
   ============================================================ */
$contacts_result = mysqli_query($conn,
    "SELECT * FROM emergency_contacts WHERE is_active = 1 ORDER BY type, name");

$contacts = [];
if ($contacts_result && mysqli_num_rows($contacts_result) > 0) {
    while ($row = mysqli_fetch_assoc($contacts_result)) {
        $contacts[] = $row;
    }
}

// Fallback if DB table empty
if (empty($contacts)) {
    $contacts = [
        ['name' => 'National Emergency',   'phone' => '911',            'type' => 'General Emergency', 'region' => 'Nationwide'],
        ['name' => 'Philippine Red Cross', 'phone' => '143',            'type' => 'Humanitarian Aid',  'region' => 'Nationwide'],
        ['name' => 'NDRRMC',               'phone' => '(02) 8911-5061', 'type' => 'Disaster Response', 'region' => 'Metro Manila'],
        ['name' => 'BFP (Fire)',           'phone' => '117',            'type' => 'Fire & Rescue',     'region' => 'Nationwide'],
        ['name' => 'PNP (Police)',         'phone' => '117',            'type' => 'Police',            'region' => 'Nationwide'],
        ['name' => 'Coast Guard',          'phone' => '(02) 8527-8481', 'type' => 'Maritime Rescue',   'region' => 'Nationwide'],
    ];
}

/* ============================================================
   Pick the primary hotline for the big alert banner.
   Priority: type containing "General Emergency" → else first contact.
   ============================================================ */
$primary_hotline = null;
foreach ($contacts as $c) {
    if (stripos($c['type'], 'general') !== false || stripos($c['name'], 'national emergency') !== false) {
        $primary_hotline = $c;
        break;
    }
}
if (!$primary_hotline) $primary_hotline = $contacts[0];

$primary_tel = preg_replace('/[^0-9]/', '', $primary_hotline['phone']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Contacts · SmartEcoTrack</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --navy-900: #0A1931;
            --navy-800: #112A4A;
            --navy-700: #1A3A63;
            --navy-600: #234B7C;
            --navy-500: #2E5F96;
            --navy-100: #E1EAF4;
            --navy-50:  #F2F6FB;

            --forest-900: #1B4332;
            --forest-800: #2D6A4F;
            --forest-700: #40916C;
            --forest-600: #52B788;
            --forest-400: #95D5B2;
            --forest-100: #EDF7F0;

            --crimson:    #C62828;
            --crimson-bg: #FDECEA;
            --amber:      #E65100;
            --amber-bg:   #FFF3E0;
            --status-green: #2E7D32;
            --status-bg:    #E8F5E9;
            --info-blue:  #1565C0;
            --info-bg:    #E3F2FD;

            --white:    #FFFFFF;
            --gray-50:  #FAFBFC;
            --gray-100: #F4F6F8;
            --gray-200: #E4E8EC;
            --gray-300: #CFD6DC;
            --gray-400: #9AA5AF;
            --gray-500: #6B7680;
            --gray-600: #4A535C;
            --gray-800: #1C2229;

            --shadow-sm: 0 1px 3px rgba(10,25,49,0.06);
            --shadow-md: 0 4px 12px rgba(10,25,49,0.08);
            --shadow-lg: 0 12px 32px rgba(10,25,49,0.10);

            --radius-sm: 6px;
            --radius-md: 10px;
            --radius-lg: 16px;
            --radius-pill: 999px;

            --gradient-header: linear-gradient(135deg, var(--navy-800), var(--navy-600));
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
            background: var(--gray-100);
            color: var(--gray-800);
            line-height: 1.6;
            padding-top: 88px;
            -webkit-font-smoothing: antialiased;
        }

        /* ——— NAVBAR ——— */
        .navbar {
            position: fixed;
            top: 0; left: 0; width: 100%;
            padding: 0.75rem 5vw;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 999;
            background: var(--white);
            border-bottom: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            color: var(--navy-800);
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            flex-shrink: 0;
        }
        .logo-circle {
            width: 56px; height: 56px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--navy-50);
            box-shadow: 0 0 0 2.5px var(--navy-500), 0 4px 12px rgba(10,25,49,0.15);
            flex-shrink: 0;
        }
        .logo-circle img { width: 100%; height: 100%; object-fit: cover; }
        .logo-text em { font-style: normal; font-weight: 400; color: var(--gray-500); }

        .nav-links { display: flex; gap: 0.35rem; align-items: center; flex-wrap: wrap; }
        .nav-links a {
            color: var(--gray-600);
            text-decoration: none;
            padding: 0.5rem 0.95rem;
            border-radius: var(--radius-sm);
            font-weight: 500;
            font-size: 0.88rem;
            transition: all 0.15s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }
        .nav-links a:hover { background: var(--navy-50); color: var(--navy-800); }
        .nav-links a.active { background: var(--navy-700); color: var(--white); }
        .nav-links a.btn-report {
            background: var(--forest-700);
            color: var(--white);
            font-weight: 600;
        }
        .nav-links a.btn-report:hover { background: var(--forest-800); }
        .nav-links a.admin-link {
            background: linear-gradient(135deg, #FFD700, #FFA000);
            color: #333;
            font-weight: 700;
        }
        .nav-links a.logout { color: var(--crimson); }
        .nav-links a.logout:hover { background: var(--crimson-bg); }

        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            color: var(--navy-800);
            font-size: 1.4rem;
            cursor: pointer;
            padding: 0.4rem;
        }

        /* ——— CONTAINER ——— */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 5vw 3rem;
        }

        /* ——— PAGE HEADER ——— */
        .page-header {
            background: var(--gradient-header);
            color: var(--white);
            padding: 2.5rem 2rem;
            border-radius: var(--radius-lg);
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }
        .page-header::before {
            content: '';
            position: absolute;
            inset: 0;
            background:
                radial-gradient(circle at 15% 30%, rgba(82,183,136,0.22), transparent 55%),
                radial-gradient(circle at 85% 70%, rgba(82,183,136,0.12), transparent 50%);
            pointer-events: none;
        }
        .page-header h1 {
            font-size: clamp(1.5rem, 3vw, 2rem);
            font-weight: 700;
            letter-spacing: -0.02em;
            margin-bottom: 0.4rem;
            position: relative;
            z-index: 1;
        }
        .page-header h1 i { color: var(--forest-400); margin-right: 8px; }
        .page-header p {
            opacity: 0.9;
            font-size: 0.95rem;
            position: relative;
            z-index: 1;
        }

        /* ——— EMERGENCY ALERT BANNER ——— */
        .emergency-alert {
            background: linear-gradient(95deg, #A51E1E, #C62828);
            color: var(--white);
            padding: 1.75rem 2rem;
            border-radius: var(--radius-lg);
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 12px 32px rgba(198,40,40,0.28);
            border: 1px solid rgba(255,255,255,0.10);
        }
        .emergency-alert::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 50% 50%, rgba(255,255,255,0.12), transparent 65%);
            pointer-events: none;
        }
        .emergency-alert .alert-icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            display: block;
            animation: pulseIcon 2s ease-in-out infinite;
        }
        @keyframes pulseIcon {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.12); }
        }
        .emergency-alert .alert-label {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.18em;
            font-weight: 700;
            opacity: 0.9;
            margin-bottom: 0.4rem;
            position: relative;
            z-index: 1;
        }
        .emergency-alert .hotline-number {
            font-size: clamp(2.2rem, 6vw, 3.5rem);
            font-weight: 800;
            letter-spacing: -0.03em;
            line-height: 1.1;
            text-shadow: 0 2px 16px rgba(0,0,0,0.35);
            position: relative;
            z-index: 1;
            margin-bottom: 0.4rem;
        }
        .emergency-alert .hotline-sub {
            font-size: 0.92rem;
            opacity: 0.92;
            margin-bottom: 1.25rem;
            position: relative;
            z-index: 1;
        }
        .emergency-alert .alert-call-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 0.85rem 2rem;
            background: var(--white);
            color: var(--crimson);
            text-decoration: none;
            border-radius: var(--radius-pill);
            font-weight: 800;
            font-size: 1rem;
            letter-spacing: 0.02em;
            transition: all 0.15s ease;
            position: relative;
            z-index: 1;
            box-shadow: 0 8px 20px rgba(0,0,0,0.20);
            border: none;
            cursor: pointer;
        }
        .emergency-alert .alert-call-btn:hover {
            background: #FFEBEE;
            transform: translateY(-2px);
            box-shadow: 0 12px 28px rgba(0,0,0,0.28);
            color: var(--crimson);
        }

        /* ——— SECTION TITLE ——— */
        .section-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--navy-900);
            margin-bottom: 0.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .section-title i { color: var(--forest-700); }
        .section-subtitle {
            color: var(--gray-500);
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }

        /* ——— CONTACTS GRID ——— */
        .contacts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.25rem;
            margin-bottom: 2rem;
        }
        .contact-card {
            background: var(--white);
            padding: 1.5rem 1.5rem 1.4rem;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            border-left: 4px solid var(--navy-600);
            transition: all 0.2s ease;
            position: relative;
            display: flex;
            flex-direction: column;
        }
        .contact-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
            border-left-color: var(--forest-700);
        }

        .contact-card .contact-type-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: var(--navy-50);
            color: var(--navy-700);
            padding: 3px 10px;
            border-radius: var(--radius-pill);
            font-size: 0.68rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 0.6rem;
            align-self: flex-start;
        }
        .contact-card .contact-type-chip.type-general       { background: var(--crimson-bg); color: var(--crimson); }
        .contact-card .contact-type-chip.type-fire          { background: var(--amber-bg);   color: var(--amber); }
        .contact-card .contact-type-chip.type-police        { background: var(--info-bg);    color: var(--info-blue); }
        .contact-card .contact-type-chip.type-disaster      { background: var(--status-bg);  color: var(--status-green); }

        .contact-card h3 {
            color: var(--navy-900);
            font-size: 1.05rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
            letter-spacing: -0.01em;
        }
        .contact-card .phone {
            font-size: 1.75rem;
            font-weight: 800;
            color: var(--crimson);
            letter-spacing: -0.02em;
            line-height: 1.15;
            margin: 0.3rem 0 0.5rem;
            font-variant-numeric: tabular-nums;
        }
        .contact-card .region {
            color: var(--gray-500);
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 1rem;
        }
        .contact-card .region i { color: var(--gray-400); }

        .btn-call {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 0.65rem 1.4rem;
            background: var(--forest-700);
            color: var(--white);
            text-decoration: none;
            border-radius: var(--radius-sm);
            font-weight: 600;
            font-size: 0.88rem;
            transition: all 0.15s ease;
            margin-top: auto;
            align-self: flex-start;
            box-shadow: var(--shadow-sm);
            border: none;
            cursor: pointer;
        }
        .btn-call:hover {
            background: var(--forest-800);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
            color: var(--white);
        }

        /* ——— EMPTY STATE ——— */
        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
            background: var(--white);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            color: var(--gray-500);
        }
        .empty-state i {
            font-size: 2.5rem;
            color: var(--gray-300);
            margin-bottom: 0.75rem;
            display: block;
        }

        /* ——— RESPONSIVE ——— */
        @media (max-width: 768px) {
            body { padding-top: 76px; }
            .navbar { padding: 0.6rem 1.25rem; flex-wrap: wrap; }
            .mobile-toggle { display: block; }
            .nav-links {
                display: none;
                width: 100%;
                flex-direction: column;
                align-items: stretch;
                padding: 0.75rem 0 0.25rem;
                border-top: 1px solid var(--gray-200);
                margin-top: 0.5rem;
            }
            .nav-links.active { display: flex; }
            .nav-links a { padding: 0.7rem 1rem; }
            .logo { font-size: 1.2rem; gap: 10px; }
            .logo-circle { width: 48px; height: 48px; }
            .logo-text em { display: none; }
            .container { padding: 1.5rem 1.25rem 2.5rem; }
            .page-header { padding: 1.75rem 1.25rem; }
            .emergency-alert { padding: 1.35rem 1.25rem; }
            .emergency-alert .hotline-number { font-size: 2.2rem; }
            .contacts-grid { grid-template-columns: 1fr; }
            .contact-card .phone { font-size: 1.5rem; }
        }

        :focus-visible { outline: 2px solid var(--navy-600); outline-offset: 2px; }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>

<!-- ====== NAVBAR ====== -->
<nav class="navbar">
    <a href="../dashboard.php" class="logo">
        <div class="logo-circle">
            <img src="../logo.png" alt="Logo"
                 onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\'fas fa-leaf\' style=\'color:var(--forest-700);font-size:1.5rem;\'></i>';">
        </div>
        <div class="logo-text">Smart<em>EcoTrack</em></div>
    </a>

    <button class="mobile-toggle" onclick="toggleMenu()" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <div class="nav-links" id="navbarNav">
        <a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a>

        <?php if (!$is_admin): ?>
            <a href="../report_incident.php" class="btn-report">
                <i class="fas fa-plus-circle"></i> Report Incident
            </a>
        <?php endif; ?>

        <a href="../my_reports.php"><i class="fas fa-list-check"></i> <?php echo $is_admin ? 'All Reports' : 'My Reports'; ?></a>
        <a href="disaster_tips.php"><i class="fas fa-shield-alt"></i> Tips</a>

        <?php if (!$is_admin): ?>
            <a href="quiz.php"><i class="fas fa-brain"></i> Quiz</a>
        <?php endif; ?>

        <a href="emergency_contacts.php" class="active"><i class="fas fa-phone-alt"></i> Contacts</a>
        <a href="../profile.php"><i class="fas fa-user-circle"></i> Profile</a>

        <?php if ($is_admin): ?>
            <a href="../admin/reports.php" class="admin-link">
                <i class="fas fa-crown"></i> Admin
            </a>
        <?php endif; ?>

        <a href="../logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</nav>

<!-- ====== MAIN ====== -->
<div class="container">

    <!-- Page Header -->
    <div class="page-header">
        <h1><i class="fas fa-phone-volume"></i> Emergency Contacts</h1>
        <p>Save these numbers — they save lives</p>
    </div>

    <!-- Emergency Alert — primary hotline from DB -->
    <div class="emergency-alert">
        <span class="alert-icon">🚨</span>
        <div class="alert-label">
            <?php echo htmlspecialchars(strtoupper($primary_hotline['type'] ?? 'National Emergency Hotline')); ?>
        </div>
        <div class="hotline-number"><?php echo htmlspecialchars($primary_hotline['phone']); ?></div>
        <div class="hotline-sub">
            <?php echo htmlspecialchars($primary_hotline['name']); ?>
            <?php if (!empty($primary_hotline['region'])): ?>
                · <?php echo htmlspecialchars($primary_hotline['region']); ?>
            <?php endif; ?>
            <br><strong>For life-threatening emergencies, call immediately!</strong>
        </div>
        <a href="tel:<?php echo $primary_tel; ?>" class="alert-call-btn">
            <i class="fas fa-phone"></i> Call <?php echo htmlspecialchars($primary_hotline['phone']); ?>
        </a>
    </div>

    <!-- All Contacts -->
    <h2 class="section-title"><i class="fas fa-address-book"></i> All Emergency Hotlines</h2>
    <p class="section-subtitle">Tap any number to call directly from your device</p>

    <?php if (!empty($contacts)): ?>
        <div class="contacts-grid">
            <?php foreach ($contacts as $c):
                // Determine chip class by type
                $type_lower = strtolower($c['type'] ?? '');
                $chip_class = '';
                if (strpos($type_lower, 'general') !== false || strpos($type_lower, 'emergency') !== false) $chip_class = 'type-general';
                elseif (strpos($type_lower, 'fire') !== false)   $chip_class = 'type-fire';
                elseif (strpos($type_lower, 'police') !== false) $chip_class = 'type-police';
                elseif (strpos($type_lower, 'disaster') !== false || strpos($type_lower, 'rescue') !== false) $chip_class = 'type-disaster';

                // Icon per type
                $icon = 'fa-phone';
                if (strpos($type_lower, 'fire') !== false)     $icon = 'fa-fire-extinguisher';
                elseif (strpos($type_lower, 'police') !== false) $icon = 'fa-shield-halved';
                elseif (strpos($type_lower, 'disaster') !== false) $icon = 'fa-triangle-exclamation';
                elseif (strpos($type_lower, 'medical') !== false || strpos($type_lower, 'health') !== false) $icon = 'fa-briefcase-medical';
                elseif (strpos($type_lower, 'maritime') !== false || strpos($type_lower, 'coast') !== false) $icon = 'fa-ship';
                elseif (strpos($type_lower, 'humanitarian') !== false) $icon = 'fa-hand-holding-heart';

                $tel = preg_replace('/[^0-9]/', '', $c['phone']);
            ?>
            <div class="contact-card">
                <span class="contact-type-chip <?php echo $chip_class; ?>">
                    <i class="fas <?php echo $icon; ?>"></i>
                    <?php echo htmlspecialchars($c['type']); ?>
                </span>

                <h3><?php echo htmlspecialchars($c['name']); ?></h3>

                <div class="phone"><?php echo htmlspecialchars($c['phone']); ?></div>

                <?php if (!empty($c['region'])): ?>
                    <div class="region">
                        <i class="fas fa-map-marker-alt"></i>
                        <?php echo htmlspecialchars($c['region']); ?>
                    </div>
                <?php endif; ?>

                <a href="tel:<?php echo $tel; ?>" class="btn-call">
                    <i class="fas fa-phone"></i> Call Now
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-phone-slash"></i>
            <p>No emergency contacts available at the moment.</p>
        </div>
    <?php endif; ?>

</div>

<script>
    // Mobile menu
    function toggleMenu() {
        document.getElementById('navbarNav').classList.toggle('active');
    }
    document.addEventListener('click', function(e) {
        const nav = document.getElementById('navbarNav');
        const toggle = document.querySelector('.mobile-toggle');
        if (nav.classList.contains('active') &&
            !nav.contains(e.target) && !toggle.contains(e.target)) {
            nav.classList.remove('active');
        }
    });
</script>
</body>
</html>