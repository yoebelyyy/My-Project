<?php
require_once '../db_connect.php';

$result = mysqli_query($conn, "SELECT * FROM evacuation_routes ORDER BY name");
$routes = [];
while ($route = mysqli_fetch_assoc($result)) {
    $routes[] = $route;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evacuation Routes - SmartEcoTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="../dashboard.php">
                <i class="fas fa-leaf"></i> SmartEcoTrack
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard.php">Dashboard</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="hero-section mb-4">
            <h1><i class="fas fa-route"></i> Evacuation Routes</h1>
            <p>Know your nearest evacuation centers and safe routes</p>
        </div>

        <div class="row">
            <div class="col-md-8">
                <div id="evacuation-map" class="map-container"></div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-list"></i> Evacuation Centers
                    </div>
                    <div class="card-body">
                        <?php foreach ($routes as $route): ?>
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5><?php echo htmlspecialchars($route['name']); ?></h5>
                                    <p class="text-muted"><?php echo htmlspecialchars($route['description']); ?></p>
                                    <p>
                                        <strong>Type:</strong> <?php echo $route['type']; ?><br>
                                        <strong>Capacity:</strong> <?php echo number_format($route['capacity']); ?> persons<br>
                                        <strong>Facilities:</strong> <?php echo $route['facilities']; ?>
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        const map = L.map('evacuation-map').setView([14.5995, 120.9842], 11);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        
        <?php foreach ($routes as $route): ?>
            L.marker([<?php echo $route['latitude']; ?>, <?php echo $route['longitude']; ?>])
                .addTo(map)
                .bindPopup(`
                    <strong><?php echo htmlspecialchars(addslashes($route['name'])); ?></strong><br>
                    Type: <?php echo $route['type']; ?><br>
                    Capacity: <?php echo $route['capacity']; ?><br>
                    Facilities: <?php echo $route['facilities']; ?>
                `);
        <?php endforeach; ?>
    </script>
</body>
</html>