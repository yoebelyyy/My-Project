<?php
require_once '../db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preparedness Guide - SmartEcoTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .guide-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .guide-section h3 {
            color: #1B4D3E;
            border-bottom: 3px solid #4CAF50;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .checklist-item {
            padding: 10px;
            margin: 5px 0;
            background: #F1F8E9;
            border-radius: 8px;
            display: flex;
            align-items: center;
        }
        .checklist-item i {
            color: #4CAF50;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="../dashboard.php">
                <i class="fas fa-leaf"></i> SmartEcoTrack
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../dashboard.php">Dashboard</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="hero-section mb-4">
            <h1><i class="fas fa-book-medical"></i> Disaster Preparedness Guide</h1>
            <p>Comprehensive guide to help you prepare for various disasters</p>
        </div>

        <!-- Emergency Kit Checklist -->
        <div class="guide-section">
            <h3><i class="fas fa-first-aid"></i> Emergency Kit Checklist</h3>
            <div class="row">
                <div class="col-md-6">
                    <h5>Basic Supplies</h5>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Water (1 gallon per person per day for 3 days)</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Non-perishable food (3-day supply)</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Battery-powered radio</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Flashlight with extra batteries</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> First aid kit</div>
                </div>
                <div class="col-md-6">
                    <h5>Additional Items</h5>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Whistle to signal for help</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Dust masks</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Moist towelettes and garbage bags</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Wrench or pliers for utilities</div>
                    <div class="checklist-item"><i class="fas fa-check-circle"></i> Local maps</div>
                </div>
            </div>
        </div>

        <!-- Family Emergency Plan -->
        <div class="guide-section">
            <h3><i class="fas fa-users"></i> Family Emergency Plan</h3>
            <ol>
                <li><strong>Communication Plan:</strong> Designate an out-of-area contact person</li>
                <li><strong>Meeting Places:</strong> Choose two meeting spots - one near home, one outside neighborhood</li>
                <li><strong>Evacuation Routes:</strong> Know multiple ways to leave your area</li>
                <li><strong>Important Documents:</strong> Keep copies in waterproof container</li>
                <li><strong>Pet Plan:</strong> Include pets in your emergency planning</li>
            </ol>
        </div>

        <!-- Specific Disaster Guides -->
        <div class="guide-section">
            <h3><i class="fas fa-water"></i> Flood Preparedness</h3>
            <ul>
                <li>Know your area's flood risk</li>
                <li>Elevate furnace, water heater, and electric panel</li>
                <li>Install check valves in sewer traps</li>
                <li>Construct barriers to stop floodwater</li>
                <li>Seal basement walls with waterproofing compounds</li>
            </ul>
        </div>

        <div class="guide-section">
            <h3><i class="fas fa-wind"></i> Typhoon Preparedness</h3>
            <ul>
                <li>Trim trees and shrubs around your home</li>
                <li>Secure loose outdoor items</li>
                <li>Reinforce garage doors</li>
                <li>Install storm shutters or board up windows</li>
                <li>Stay informed through PAGASA updates</li>
            </ul>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>