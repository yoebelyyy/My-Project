<?php
require_once '../db_connect.php';
if (!isLoggedIn()) redirect('login.php');

$user_id = (int)$_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id"));
if (!$user) { session_destroy(); redirect('login.php'); }

$is_admin = (isset($user['role']) && strtolower($user['role']) === 'admin');

/* ============================================================
   Fetch disaster tips
   ============================================================ */
$tips_result = mysqli_query($conn, "SELECT * FROM disaster_tips ORDER BY category, title");

$tips = [];
if ($tips_result && mysqli_num_rows($tips_result) > 0) {
    while ($row = mysqli_fetch_assoc($tips_result)) {
        $tips[] = $row;
    }
}

// Fallback if DB is empty
if (empty($tips)) {
    $tips = [
        ['title' => 'Earthquake Safety',    'category' => 'Geological',    'icon' => 'mountain',          'image_url' => '', 'content' => 'Drop, cover, and hold on. Stay away from windows and heavy furniture. If outdoors, move to an open area away from buildings, trees, and power lines. If driving, pull over safely and stay inside the vehicle.'],
        ['title' => 'Typhoon Preparedness', 'category' => 'Weather',       'icon' => 'wind',              'image_url' => '', 'content' => 'Secure loose objects, stock up on food and water, know your evacuation zone. Monitor official weather updates from PAGASA. Trim trees, reinforce windows, and prepare an emergency kit with flashlights, batteries, first aid, and important documents.'],
        ['title' => 'Flood Response',       'category' => 'Hydrological',  'icon' => 'water',             'image_url' => '', 'content' => 'Move to higher ground immediately. Avoid walking or driving through floodwaters — 6 inches of moving water can knock you down. Turn off gas and electricity. Do not touch electrical equipment if wet.'],
        ['title' => 'Wildfire Awareness',   'category' => 'Environmental', 'icon' => 'fire',              'image_url' => '', 'content' => 'Clear dry vegetation around your home (at least 30 feet). Have an evacuation plan and a go-bag ready. Follow evacuation orders promptly. Close windows and vents to keep smoke out.'],
        ['title' => 'Landslide Safety',     'category' => 'Geological',    'icon' => 'hill-rockslide',    'image_url' => '', 'content' => 'Watch for warning signs: cracks in walls, tilting trees, sudden water flow. Evacuate immediately if you hear rumbling. Move perpendicular to the slide path. Avoid river valleys and low-lying areas.'],
        ['title' => 'Volcanic Eruption',    'category' => 'Geological',    'icon' => 'fire-flame-curved', 'image_url' => '', 'content' => 'Follow PHIVOLCS advisories. Wear N95 masks to filter ash. Close windows and doors. Clear ash from roofs carefully to prevent collapse. Avoid river valleys where lahars can flow.'],
        ['title' => 'Wildlife Protection',  'category' => 'Wildlife',      'icon' => 'dove',              'image_url' => '', 'content' => 'Protect natural habitats. Report illegal wildlife trade. Avoid feeding wild animals. Support conservation programs. Keep a safe distance from wild animals in their habitat.'],
        ['title' => 'Air Pollution Action', 'category' => 'Pollution',     'icon' => 'smog',              'image_url' => '', 'content' => 'Reduce vehicle use, avoid burning trash, plant more trees. Wear masks on high pollution days. Support clean energy initiatives. Report industrial smoke emissions to authorities.'],
    ];
}

// Collect unique categories
$categories = [];
foreach ($tips as $t) {
    $cat = $t['category'] ?? 'General';
    if (!in_array($cat, $categories)) $categories[] = $cat;
}
sort($categories);

$total_tips = count($tips);

/* ============================================================
   Cartoon SVG illustration per category
   ============================================================ */
function getDisasterIllustration($category) {
    $cat = strtolower($category ?? 'general');

    // ——— GEOLOGICAL ———
    if (strpos($cat, 'geolog') !== false || strpos($cat, 'earthquake') !== false
        || strpos($cat, 'landslide') !== false || strpos($cat, 'volcan') !== false) {
        return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <circle cx="340" cy="50" r="26" fill="#FFD54F" opacity="0.85"/>
    <circle cx="340" cy="50" r="34" fill="#FFD54F" opacity="0.25"/>
    <path d="M40 180 L120 90 L200 180 Z" fill="#546E7A"/>
    <path d="M120 90 L140 115 L100 115 Z" fill="#FFFFFF" opacity="0.9"/>
    <path d="M180 180 L270 70 L360 180 Z" fill="#455A64"/>
    <path d="M270 70 L295 100 L245 100 Z" fill="#FFFFFF" opacity="0.9"/>
    <path d="M0 180 Q30 170 60 180 T120 180 T180 180 T240 180 T300 180 T360 180 T400 180 L400 220 L0 220 Z" fill="#8D6E63"/>
    <path d="M0 195 Q25 188 50 195 T100 195 T150 195 T200 195 T250 195 T300 195 T350 195 T400 195" fill="none" stroke="#5D4037" stroke-width="2" opacity="0.6"/>
    <path d="M150 195 L165 205 L155 210 L175 215" fill="none" stroke="#3E2723" stroke-width="2.5" stroke-linecap="round" class="floaty"/>
    <g class="floaty">
        <rect x="52" y="150" width="34" height="30" fill="#FFF3E0" stroke="#5D4037" stroke-width="2"/>
        <path d="M48 150 L69 130 L90 150 Z" fill="#D32F2F" stroke="#5D4037" stroke-width="2" stroke-linejoin="round"/>
        <rect x="60" y="162" width="10" height="18" fill="#5D4037"/>
    </g>
</svg>
SVG;
    }

    // ——— WEATHER ———
    if (strpos($cat, 'weather') !== false || strpos($cat, 'typhoon') !== false
        || strpos($cat, 'storm') !== false) {
        return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <g class="floaty" transform="translate(200,110)">
        <path d="M0,-70 A70,70 0 1,1 -70,0" fill="none" stroke="#0288D1" stroke-width="10" stroke-linecap="round" opacity="0.85"/>
        <path d="M0,-50 A50,50 0 1,1 -50,0" fill="none" stroke="#039BE5" stroke-width="9" stroke-linecap="round" opacity="0.85"/>
        <path d="M0,-30 A30,30 0 1,1 -30,0" fill="none" stroke="#4FC3F7" stroke-width="8" stroke-linecap="round" opacity="0.9"/>
        <circle r="8" fill="#0277BD"/>
    </g>
    <g opacity="0.9">
        <ellipse cx="90" cy="55" rx="42" ry="18" fill="#90A4AE"/>
        <ellipse cx="120" cy="48" rx="30" ry="15" fill="#B0BEC5"/>
        <ellipse cx="320" cy="180" rx="42" ry="18" fill="#90A4AE"/>
        <ellipse cx="295" cy="172" rx="30" ry="15" fill="#B0BEC5"/>
    </g>
    <g stroke="#4FC3F7" stroke-width="3" stroke-linecap="round" opacity="0.7">
        <line x1="70" y1="90" x2="63" y2="110"/>
        <line x1="95" y1="90" x2="88" y2="110"/>
        <line x1="120" y1="90" x2="113" y2="110"/>
        <line x1="300" y1="140" x2="293" y2="160"/>
        <line x1="325" y1="140" x2="318" y2="160"/>
    </g>
</svg>
SVG;
    }

    // ——— HYDROLOGICAL ———
    if (strpos($cat, 'hydro') !== false || strpos($cat, 'flood') !== false
        || strpos($cat, 'water') !== false) {
        return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <circle cx="60" cy="55" r="22" fill="#FFD54F" opacity="0.7"/>
    <g class="floaty">
        <rect x="150" y="80" width="100" height="60" fill="#FFF3E0" stroke="#5D4037" stroke-width="2.5"/>
        <path d="M140 80 L200 45 L260 80 Z" fill="#D32F2F" stroke="#5D4037" stroke-width="2.5" stroke-linejoin="round"/>
        <rect x="185" y="105" width="30" height="35" fill="#5D4037"/>
        <rect x="165" y="95" width="16" height="16" fill="#4FC3F7"/>
        <rect x="220" y="95" width="16" height="16" fill="#4FC3F7"/>
    </g>
    <path d="M0 150 Q40 135 80 150 T160 150 T240 150 T320 150 T400 150 L400 220 L0 220 Z" fill="#29B6F6" opacity="0.85"/>
    <path d="M0 165 Q40 152 80 165 T160 165 T240 165 T320 165 T400 165 L400 220 L0 220 Z" fill="#0288D1" opacity="0.9"/>
    <path d="M0 185 Q40 172 80 185 T160 185 T240 185 T320 185 T400 185 L400 220 L0 220 Z" fill="#01579B"/>
    <circle cx="90" cy="158" r="3" fill="#FFFFFF" opacity="0.8"/>
    <circle cx="180" cy="162" r="2.5" fill="#FFFFFF" opacity="0.8"/>
    <circle cx="270" cy="157" r="3" fill="#FFFFFF" opacity="0.8"/>
    <circle cx="340" cy="163" r="2.5" fill="#FFFFFF" opacity="0.8"/>
</svg>
SVG;
    }

    // ——— ENVIRONMENTAL ———
    if (strpos($cat, 'environ') !== false || strpos($cat, 'wildfire') !== false
        || strpos($cat, 'fire') !== false) {
        return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <g opacity="0.5">
        <ellipse cx="200" cy="40" rx="55" ry="22" fill="#9E9E9E"/>
        <ellipse cx="260" cy="55" rx="40" ry="18" fill="#BDBDBD"/>
        <ellipse cx="140" cy="55" rx="40" ry="18" fill="#BDBDBD"/>
    </g>
    <g class="floaty">
        <path d="M200 190 Q160 150 180 110 Q185 130 200 100 Q215 130 220 110 Q240 150 200 190 Z" fill="#FF5722"/>
        <path d="M200 185 Q175 155 190 125 Q195 140 200 120 Q205 140 210 125 Q225 155 200 185 Z" fill="#FF9800"/>
        <path d="M200 180 Q185 160 195 140 Q200 150 200 145 Q200 150 205 140 Q215 160 200 180 Z" fill="#FFC107"/>
    </g>
    <g>
        <rect x="60" y="160" width="8" height="35" fill="#5D4037"/>
        <path d="M64 130 L40 170 L88 170 Z" fill="#2E7D32"/>
        <rect x="330" y="160" width="8" height="35" fill="#5D4037"/>
        <path d="M334 130 L310 170 L358 170 Z" fill="#2E7D32"/>
    </g>
    <path d="M0 190 Q200 180 400 190 L400 220 L0 220 Z" fill="#8D6E63"/>
</svg>
SVG;
    }

    // ——— WILDLIFE ———
    if (strpos($cat, 'wildlife') !== false) {
        return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <circle cx="330" cy="50" r="24" fill="#FFD54F" opacity="0.7"/>
    <g class="floaty" transform="translate(200,100)">
        <path d="M-70,-10 Q-35,-25 -10,-10 L0,-15 L10,-10 Q35,-25 70,-10 Q40,0 15,5 L0,0 L-15,5 Q-40,0 -70,-10 Z" fill="#5D4037"/>
        <circle cx="0" cy="-18" r="6" fill="#5D4037"/>
        <path d="M6,-18 L12,-16 L6,-14 Z" fill="#FF9800"/>
    </g>
    <g>
        <rect x="70" y="170" width="6" height="30" fill="#5D4037"/>
        <path d="M73 130 L50 175 L96 175 Z" fill="#2E7D32"/>
        <path d="M73 145 L55 175 L91 175 Z" fill="#388E3C"/>
        <rect x="330" y="170" width="6" height="30" fill="#5D4037"/>
        <path d="M333 130 L310 175 L356 175 Z" fill="#2E7D32"/>
        <path d="M333 145 L315 175 L351 175 Z" fill="#388E3C"/>
    </g>
    <path d="M0 195 Q200 188 400 195 L400 220 L0 220 Z" fill="#7CB342"/>
</svg>
SVG;
    }

    // ——— POLLUTION ———
    if (strpos($cat, 'pollut') !== false) {
        return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <rect width="400" height="160" fill="#B0BEC5" opacity="0.3"/>
    <g class="floaty">
        <rect x="130" y="110" width="140" height="70" fill="#78909C" stroke="#455A64" stroke-width="2"/>
        <rect x="150" y="80" width="20" height="30" fill="#607D8B"/>
        <rect x="200" y="70" width="22" height="40" fill="#607D8B"/>
        <rect x="245" y="90" width="18" height="20" fill="#607D8B"/>
        <rect x="145" y="130" width="14" height="14" fill="#FFC107"/>
        <rect x="170" y="130" width="14" height="14" fill="#FFC107"/>
        <rect x="195" y="130" width="14" height="14" fill="#FFC107"/>
        <rect x="220" y="130" width="14" height="14" fill="#FFC107"/>
        <rect x="245" y="130" width="14" height="14" fill="#FFC107"/>
        <g opacity="0.65">
            <circle cx="160" cy="65" r="12" fill="#9E9E9E"/>
            <circle cx="172" cy="52" r="14" fill="#BDBDBD"/>
            <circle cx="188" cy="45" r="12" fill="#9E9E9E"/>
            <circle cx="210" cy="50" r="15" fill="#BDBDBD"/>
            <circle cx="228" cy="42" r="12" fill="#9E9E9E"/>
            <circle cx="255" cy="75" r="10" fill="#BDBDBD"/>
        </g>
    </g>
    <path d="M0 180 L400 180 L400 220 L0 220 Z" fill="#795548"/>
    <path d="M0 180 L400 180" stroke="#4E342E" stroke-width="2" opacity="0.5"/>
</svg>
SVG;
    }

    // ——— GENERAL (default) ———
    return <<<'SVG'
<svg viewBox="0 0 400 220" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
    <g class="floaty" transform="translate(200,110)">
        <path d="M0,-70 L60,-45 L60,20 Q60,60 0,80 Q-60,60 -60,20 L-60,-45 Z" fill="#40916C" stroke="#1B4332" stroke-width="3" stroke-linejoin="round"/>
        <path d="M0,-55 L48,-35 L48,18 Q48,50 0,68 Q-48,50 -48,18 L-48,-35 Z" fill="#52B788"/>
        <path d="M-20,5 L-6,20 L22,-15" fill="none" stroke="#FFFFFF" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <path d="M40 60 Q55 45 75 55 Q60 70 40 60 Z" fill="#52B788" opacity="0.6"/>
    <path d="M320 165 Q335 150 355 160 Q340 175 320 165 Z" fill="#52B788" opacity="0.6"/>
</svg>
SVG;
}

/* Map a category to an illustration class */
function getIllustrationClass($category) {
    $c = strtolower($category ?? 'general');
    if (strpos($c, 'geolog') !== false || strpos($c, 'earthquake') !== false
        || strpos($c, 'landslide') !== false || strpos($c, 'volcan') !== false) return 'ill-geological';
    if (strpos($c, 'weather') !== false || strpos($c, 'typhoon') !== false
        || strpos($c, 'storm') !== false) return 'ill-weather';
    if (strpos($c, 'hydro') !== false || strpos($c, 'flood') !== false
        || strpos($c, 'water') !== false) return 'ill-hydrological';
    if (strpos($c, 'environ') !== false || strpos($c, 'wildfire') !== false
        || strpos($c, 'fire') !== false) return 'ill-environmental';
    if (strpos($c, 'wildlife') !== false) return 'ill-wildlife';
    if (strpos($c, 'pollut') !== false) return 'ill-pollution';
    return 'ill-general';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disaster Tips · SmartEcoTrack</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --navy-900: #0A1931;
            --navy-800: #112A4A;
            --navy-700: #1A3A63;
            --navy-600: #234B7C;
            --navy-500: #2E5F96;
            --navy-100: #E1EAF4;
            --navy-50:  #F2F6FB;

            --forest-900: #1B4332;
            --forest-800: #2D6A4F;
            --forest-700: #40916C;
            --forest-600: #52B788;
            --forest-400: #95D5B2;
            --forest-100: #EDF7F0;

            --crimson:    #C62828;
            --crimson-bg: #FDECEA;
            --amber:      #E65100;
            --amber-bg:   #FFF3E0;
            --status-green: #2E7D32;
            --status-bg:    #E8F5E9;
            --info-blue:  #1565C0;
            --info-bg:    #E3F2FD;

            --white:    #FFFFFF;
            --gray-50:  #FAFBFC;
            --gray-100: #F4F6F8;
            --gray-200: #E4E8EC;
            --gray-300: #CFD6DC;
            --gray-400: #9AA5AF;
            --gray-500: #6B7680;
            --gray-600: #4A535C;
            --gray-800: #1C2229;

            --shadow-sm: 0 1px 3px rgba(10,25,49,0.06);
            --shadow-md: 0 4px 12px rgba(10,25,49,0.08);
            --shadow-lg: 0 12px 32px rgba(10,25,49,0.10);

            --radius-sm: 6px;
            --radius-md: 10px;
            --radius-lg: 16px;
            --radius-pill: 999px;

            --gradient-header: linear-gradient(135deg, var(--navy-800), var(--navy-600));
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
            background: var(--gray-100);
            color: var(--gray-800);
            line-height: 1.6;
            padding-top: 88px;
            -webkit-font-smoothing: antialiased;
        }

        /* ——— NAVBAR ——— */
        .navbar {
            position: fixed;
            top: 0; left: 0; width: 100%;
            padding: 0.75rem 5vw;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 999;
            background: var(--white);
            border-bottom: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            color: var(--navy-800);
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            flex-shrink: 0;
        }
        .logo-circle {
            width: 56px; height: 56px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--navy-50);
            box-shadow: 0 0 0 2.5px var(--navy-500), 0 4px 12px rgba(10,25,49,0.15);
            flex-shrink: 0;
        }
        .logo-circle img { width: 100%; height: 100%; object-fit: cover; }
        .logo-text em { font-style: normal; font-weight: 400; color: var(--gray-500); }

        .nav-links { display: flex; gap: 0.35rem; align-items: center; flex-wrap: wrap; }
        .nav-links a {
            color: var(--gray-600);
            text-decoration: none;
            padding: 0.5rem 0.95rem;
            border-radius: var(--radius-sm);
            font-weight: 500;
            font-size: 0.88rem;
            transition: all 0.15s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }
        .nav-links a:hover { background: var(--navy-50); color: var(--navy-800); }
        .nav-links a.active { background: var(--navy-700); color: var(--white); }
        .nav-links a.btn-report {
            background: var(--forest-700);
            color: var(--white);
            font-weight: 600;
        }
        .nav-links a.btn-report:hover { background: var(--forest-800); }
        .nav-links a.admin-link {
            background: linear-gradient(135deg, #FFD700, #FFA000);
            color: #333;
            font-weight: 700;
        }
        .nav-links a.logout { color: var(--crimson); }
        .nav-links a.logout:hover { background: var(--crimson-bg); }

        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            color: var(--navy-800);
            font-size: 1.4rem;
            cursor: pointer;
            padding: 0.4rem;
        }

        /* ——— CONTAINER ——— */
        .container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 2rem 5vw 3rem;
        }

        /* ——— PAGE HEADER ——— */
        .page-header {
            background: var(--gradient-header);
            color: var(--white);
            padding: 2.5rem 2rem;
            border-radius: var(--radius-lg);
            margin-bottom: 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }
        .page-header::before {
            content: '';
            position: absolute;
            inset: 0;
            background:
                radial-gradient(circle at 15% 30%, rgba(82,183,136,0.22), transparent 55%),
                radial-gradient(circle at 85% 70%, rgba(82,183,136,0.12), transparent 50%);
            pointer-events: none;
        }
        .page-header h1 {
            font-size: clamp(1.5rem, 3vw, 2rem);
            font-weight: 700;
            letter-spacing: -0.02em;
            margin-bottom: 0.4rem;
            position: relative;
            z-index: 1;
        }
        .page-header h1 i { color: var(--forest-400); margin-right: 8px; }
        .page-header p {
            opacity: 0.9;
            font-size: 0.95rem;
            position: relative;
            z-index: 1;
        }
        .page-header .count-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-top: 0.9rem;
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.20);
            padding: 5px 14px;
            border-radius: var(--radius-pill);
            font-size: 0.82rem;
            font-weight: 600;
            position: relative;
            z-index: 1;
        }
        .page-header .count-badge i { color: var(--forest-400); }

        /* ——— TOOLBAR ——— */
        .toolbar {
            background: var(--white);
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-lg);
            padding: 1rem 1.25rem;
            margin-bottom: 1.75rem;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            gap: 0.9rem;
        }
        .search-wrap { position: relative; width: 100%; }
        .search-wrap i {
            position: absolute;
            left: 16px; top: 50%;
            transform: translateY(-50%);
            color: var(--gray-400);
            font-size: 0.95rem;
            pointer-events: none;
        }
        .search-input {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.75rem;
            border: 1.5px solid var(--gray-300);
            border-radius: var(--radius-sm);
            font-size: 0.92rem;
            font-family: inherit;
            color: var(--gray-800);
            background: var(--white);
            outline: none;
            transition: all 0.15s ease;
        }
        .search-input:focus {
            border-color: var(--navy-500);
            box-shadow: 0 0 0 3px rgba(46,95,150,0.15);
        }
        .search-input::placeholder { color: var(--gray-400); }

        .filter-chips { display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center; }
        .chip {
            padding: 6px 14px;
            border-radius: var(--radius-pill);
            border: 1.5px solid var(--gray-300);
            background: var(--white);
            color: var(--gray-600);
            font-size: 0.82rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
            font-family: inherit;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .chip:hover { border-color: var(--navy-500); color: var(--navy-700); background: var(--navy-50); }
        .chip.active { background: var(--navy-700); color: var(--white); border-color: var(--navy-700); }
        .chip .count {
            background: rgba(255,255,255,0.25);
            padding: 1px 7px;
            border-radius: var(--radius-pill);
            font-size: 0.72rem;
            font-weight: 700;
        }
        .chip:not(.active) .count { background: var(--gray-100); color: var(--gray-600); }

        /* ——— TIPS GRID ——— */
        .tips-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 1.5rem;
        }

        .tip-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            transition: all 0.2s ease;
            display: flex;
            flex-direction: column;
        }
        .tip-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
            border-color: var(--forest-400);
        }

        /* ——— CARTOON ILLUSTRATION ——— */
        .tip-illustration {
            position: relative;
            width: 100%;
            height: 190px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.35s ease;
        }
        .tip-card:hover .tip-illustration { transform: scale(1.04); }
        .tip-illustration svg { width: 100%; height: 100%; display: block; }

        .tip-illustration.ill-geological    { background: linear-gradient(135deg, #E8F5E9, #C8E6C9); }
        .tip-illustration.ill-weather       { background: linear-gradient(135deg, #E1F5FE, #B3E5FC); }
        .tip-illustration.ill-hydrological  { background: linear-gradient(135deg, #E3F2FD, #BBDEFB); }
        .tip-illustration.ill-environmental { background: linear-gradient(135deg, #FFF3E0, #FFE0B2); }
        .tip-illustration.ill-wildlife      { background: linear-gradient(135deg, #F1F8E9, #DCEDC8); }
        .tip-illustration.ill-pollution     { background: linear-gradient(135deg, #ECEFF1, #CFD8DC); }
        .tip-illustration.ill-general       { background: linear-gradient(135deg, #E1EAF4, #B8CFE5); }

        @keyframes floaty {
            0%, 100% { transform: translateY(0); }
            50%      { transform: translateY(-6px); }
        }
        .tip-illustration svg .floaty {
            animation: floaty 3.5s ease-in-out infinite;
            transform-origin: center;
        }

        .tip-overlay-cat {
            position: absolute;
            top: 12px;
            left: 12px;
            z-index: 2;
            background: rgba(10,25,49,0.78);
            backdrop-filter: blur(6px);
            color: var(--white);
            padding: 5px 12px;
            border-radius: var(--radius-pill);
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .tip-overlay-cat i { color: var(--forest-400); font-size: 0.7rem; }

        /* ——— CARD BODY ——— */
        .tip-body {
            padding: 1.35rem 1.4rem 1.5rem;
            display: flex;
            flex-direction: column;
            flex: 1;
        }
        .tip-body h3 {
            color: var(--navy-900);
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            letter-spacing: -0.01em;
            line-height: 1.35;
        }
        .tip-body .tip-excerpt {
            color: var(--gray-600);
            font-size: 0.9rem;
            line-height: 1.6;
            margin-bottom: 0.75rem;
            flex: 1;
        }
        .tip-body .tip-full {
            display: none;
            color: var(--gray-600);
            font-size: 0.9rem;
            line-height: 1.65;
            margin-bottom: 0.75rem;
        }
        .tip-card.expanded .tip-excerpt { display: none; }
        .tip-card.expanded .tip-full { display: block; }

        .tip-read-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--forest-700);
            font-weight: 700;
            font-size: 0.85rem;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
            margin-top: auto;
            font-family: inherit;
            transition: all 0.15s ease;
            align-self: flex-start;
        }
        .tip-read-btn:hover { color: var(--forest-800); gap: 9px; }
        .tip-read-btn i { transition: transform 0.2s ease; }
        .tip-card.expanded .tip-read-btn i { transform: rotate(180deg); }

        /* ——— EMPTY STATE ——— */
        .empty-state {
            text-align: center;
            padding: 3.5rem 2rem;
            background: var(--white);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            color: var(--gray-500);
        }
        .empty-state i {
            font-size: 3rem;
            color: var(--gray-300);
            margin-bottom: 0.75rem;
            display: block;
        }
        .empty-state h2 { color: var(--navy-900); font-size: 1.2rem; margin-bottom: 0.4rem; }

        /* ——— RESPONSIVE ——— */
        @media (max-width: 768px) {
            body { padding-top: 76px; }
            .navbar { padding: 0.6rem 1.25rem; flex-wrap: wrap; }
            .mobile-toggle { display: block; }
            .nav-links {
                display: none;
                width: 100%;
                flex-direction: column;
                align-items: stretch;
                padding: 0.75rem 0 0.25rem;
                border-top: 1px solid var(--gray-200);
                margin-top: 0.5rem;
            }
            .nav-links.active { display: flex; }
            .nav-links a { padding: 0.7rem 1rem; }
            .logo { font-size: 1.2rem; gap: 10px; }
            .logo-circle { width: 48px; height: 48px; }
            .logo-text em { display: none; }
            .container { padding: 1.5rem 1.25rem 2.5rem; }
            .page-header { padding: 1.75rem 1.25rem; }
            .tips-grid { grid-template-columns: 1fr; }
            .tip-illustration { height: 170px; }
        }

        :focus-visible { outline: 2px solid var(--navy-600); outline-offset: 2px; }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>

<!-- ====== NAVBAR ====== -->
<nav class="navbar">
    <a href="../dashboard.php" class="logo">
        <div class="logo-circle">
            <img src="../logo.png" alt="Logo"
                 onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\'fas fa-leaf\' style=\'color:var(--forest-700);font-size:1.5rem;\'></i>';">
        </div>
        <div class="logo-text">Smart<em>EcoTrack</em></div>
    </a>

    <button class="mobile-toggle" onclick="toggleMenu()" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <div class="nav-links" id="navbarNav">
        <a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a>

        <?php if (!$is_admin): ?>
            <a href="../report_incident.php" class="btn-report">
                <i class="fas fa-plus-circle"></i> Report Incident
            </a>
        <?php endif; ?>

        <a href="../my_reports.php"><i class="fas fa-list-check"></i> <?php echo $is_admin ? 'All Reports' : 'My Reports'; ?></a>
        <a href="disaster_tips.php" class="active"><i class="fas fa-shield-alt"></i> Tips</a>

        <?php if (!$is_admin): ?>
            <a href="quiz.php"><i class="fas fa-brain"></i> Quiz</a>
        <?php endif; ?>

        <a href="emergency_contacts.php"><i class="fas fa-phone-alt"></i> Contacts</a>
        <a href="../profile.php"><i class="fas fa-user-circle"></i> Profile</a>

        <?php if ($is_admin): ?>
            <a href="../admin/reports.php" class="admin-link">
                <i class="fas fa-crown"></i> Admin
            </a>
        <?php endif; ?>

        <a href="../logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</nav>

<!-- ====== MAIN ====== -->
<div class="container">

    <!-- Page Header -->
    <div class="page-header">
        <h1><i class="fas fa-book-open"></i> Disaster Preparedness Guides</h1>
        <p>Learn how to protect yourself and your loved ones during emergencies</p>
        <div class="count-badge">
            <i class="fas fa-layer-group"></i>
            <?php echo $total_tips; ?> guide<?php echo $total_tips !== 1 ? 's' : ''; ?>
        </div>
    </div>

    <!-- Toolbar -->
    <div class="toolbar">
        <div class="search-wrap">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" class="search-input"
                   placeholder="Search tips by title, category, or content…"
                   oninput="filterTips()">
        </div>

        <div class="filter-chips" id="filterChips">
            <button class="chip active" data-cat="all" onclick="setCategory('all', this)">
                <i class="fas fa-border-all"></i> All
                <span class="count"><?php echo $total_tips; ?></span>
            </button>
            <?php foreach ($categories as $cat):
                $count = 0;
                foreach ($tips as $t) if (($t['category'] ?? 'General') === $cat) $count++;
            ?>
                <button class="chip" data-cat="<?php echo htmlspecialchars(strtolower($cat)); ?>" onclick="setCategory('<?php echo htmlspecialchars(strtolower($cat)); ?>', this)">
                    <?php echo htmlspecialchars($cat); ?>
                    <span class="count"><?php echo $count; ?></span>
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Tips Grid -->
    <?php if (!empty($tips)): ?>
        <div class="tips-grid" id="tipsGrid">
            <?php foreach ($tips as $i => $tip):
                $icon     = !empty($tip['icon']) ? $tip['icon'] : 'exclamation-triangle';
                $cat      = !empty($tip['category']) ? $tip['category'] : 'General';
                $title    = $tip['title'] ?? 'Untitled';
                $content  = $tip['content'] ?? '';
                $excerpt  = mb_strlen($content) > 140 ? mb_substr($content, 0, 140) . '…' : $content;
                $ill_class = getIllustrationClass($cat);
            ?>
            <div class="tip-card"
                 data-category="<?php echo htmlspecialchars(strtolower($cat)); ?>"
                 data-search="<?php echo htmlspecialchars(strtolower($title . ' ' . $cat . ' ' . $content)); ?>"
                 id="tip-<?php echo $i; ?>">

                <div class="tip-illustration <?php echo $ill_class; ?>">
                    <span class="tip-overlay-cat">
                        <i class="fas fa-<?php echo htmlspecialchars($icon); ?>"></i>
                        <?php echo htmlspecialchars($cat); ?>
                    </span>
                    <?php echo getDisasterIllustration($cat); ?>
                </div>

                <div class="tip-body">
                    <h3><?php echo htmlspecialchars($title); ?></h3>

                    <p class="tip-excerpt"><?php echo htmlspecialchars($excerpt); ?></p>
                    <p class="tip-full"><?php echo nl2br(htmlspecialchars($content)); ?></p>

                    <?php if (mb_strlen($content) > 140): ?>
                        <button class="tip-read-btn" onclick="toggleTip('tip-<?php echo $i; ?>', this)">
                            <span class="btn-label">Read more</span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- No results message -->
        <div class="empty-state" id="noResults" style="display:none; margin-top: 1.5rem;">
            <i class="fas fa-search"></i>
            <h2>No matching tips</h2>
            <p>Try a different search term or category.</p>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-book"></i>
            <h2>No disaster tips available</h2>
            <p>Please check back later.</p>
        </div>
    <?php endif; ?>

</div>

<script>
    /* Mobile menu */
    function toggleMenu() {
        document.getElementById('navbarNav').classList.toggle('active');
    }
    document.addEventListener('click', function(e) {
        const nav = document.getElementById('navbarNav');
        const toggle = document.querySelector('.mobile-toggle');
        if (nav.classList.contains('active') &&
            !nav.contains(e.target) && !toggle.contains(e.target)) {
            nav.classList.remove('active');
        }
    });

    /* Expand / collapse tip */
    function toggleTip(id, btn) {
        const card = document.getElementById(id);
        card.classList.toggle('expanded');
        const label = btn.querySelector('.btn-label');
        label.textContent = card.classList.contains('expanded') ? 'Show less' : 'Read more';
    }

    /* Filter */
    let activeCategory = 'all';
    function setCategory(cat, el) {
        activeCategory = cat;
        document.querySelectorAll('#filterChips .chip').forEach(c => c.classList.remove('active'));
        el.classList.add('active');
        filterTips();
    }
    function filterTips() {
        const q = document.getElementById('searchInput').value.trim().toLowerCase();
        const cards = document.querySelectorAll('.tip-card');
        let visible = 0;
        cards.forEach(card => {
            const catMatch = (activeCategory === 'all') || (card.dataset.category === activeCategory);
            const searchMatch = q === '' || card.dataset.search.includes(q);
            if (catMatch && searchMatch) { card.style.display = ''; visible++; }
            else { card.style.display = 'none'; }
        });
        const noResults = document.getElementById('noResults');
        if (noResults) noResults.style.display = visible === 0 ? 'block' : 'none';
    }
</script>
</body>
</html>