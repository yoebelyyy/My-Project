<?php
/* ============================================================
   FILE: modules/quiz.php
   Purpose: Gamified disaster preparedness quiz
            - 1 question at a time
            - 20s timer per question
            - 3 lives
            - Points → Relief goods vouchers
   ============================================================ */

require_once '../db_connect.php';
if (!isLoggedIn()) redirect('../login.php');

$user_id = (int)$_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id"));
if (!$user) { session_destroy(); redirect('../login.php'); }

$role       = strtolower(trim($user['role'] ?? 'user'));
$is_regular = ($role !== 'admin' && $role !== 'staff');

/* ---------- Load 15 random questions (no repeats) ---------- */
$questions = [];
$qResult = @mysqli_query($conn,
    "SELECT * FROM quiz_questions ORDER BY RAND() LIMIT 15");
if ($qResult) {
    while ($row = mysqli_fetch_assoc($qResult)) {
        /* Normalize for JS */
        $opts = [];
        foreach (['A','B','C','D'] as $L) {
            $key = 'option_' . strtolower($L);
            if (!empty(trim($row[$key] ?? ''))) {
                $opts[$L] = $row[$key];
            }
        }

        $questions[] = [
            'id'       => (int)$row['id'],
            'question' => $row['question'] ?? 'Untitled',
            'category' => $row['category'] ?? 'General',
            'points'   => (int)($row['points'] ?? 10),
            'correct'  => strtoupper(trim($row['correct_answer'] ?? 'A')),
            'options'  => $opts,
        ];
    }
}

$totalQuestions = count($questions);
$myScore        = (int)($user['quiz_score'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0A1931">
<title>Quiz · SmartEcoTrack</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
    --navy-900:#0A1931;--navy-800:#112A4A;--navy-700:#1A3A63;--navy-600:#234B7C;
    --navy-500:#2E5F96;--navy-300:#7BA4CE;--navy-100:#E1EAF4;--navy-50:#F2F6FB;
    --forest-900:#1B4332;--forest-800:#2D6A4F;--forest-700:#40916C;--forest-600:#52B788;
    --forest-400:#95D5B2;--forest-100:#EDF7F0;
    --crimson:#C62828;--crimson-bg:#FDECEA;
    --amber:#E65100;--amber-bg:#FFF3E0;
    --yellow:#F9A825;--yellow-bg:#FFFDE7;
    --status-green:#2E7D32;--status-bg:#E8F5E9;
    --info-blue:#1565C0;--info-bg:#E3F2FD;
    --white:#FFFFFF;--gray-50:#FAFBFC;--gray-100:#F4F6F8;--gray-200:#E4E8EC;
    --gray-300:#CFD6DC;--gray-400:#9AA5AF;--gray-500:#6B7680;--gray-600:#4A535C;--gray-800:#1C2229;
    --shadow-sm:0 1px 3px rgba(10,25,49,0.06);
    --shadow-md:0 4px 12px rgba(10,25,49,0.08);
    --shadow-lg:0 12px 32px rgba(10,25,49,0.10);
    --shadow-xl:0 20px 50px rgba(10,25,49,0.15);
    --radius-sm:6px;--radius-md:10px;--radius-lg:16px;--radius-xl:22px;--radius-pill:999px;
    --gradient-header:linear-gradient(135deg,var(--navy-800),var(--navy-600));
    --gradient-accent:linear-gradient(135deg,var(--forest-800),var(--forest-600));
}
body{font-family:'Inter',system-ui,sans-serif;background:var(--gray-100);color:var(--gray-800);
     line-height:1.6;padding-top:88px;-webkit-font-smoothing:antialiased;overflow-x:hidden;}

/* NAVBAR */
.navbar{position:fixed;top:0;left:0;width:100%;padding:0.75rem 5vw;
        display:flex;justify-content:space-between;align-items:center;z-index:999;
        background:var(--white);border-bottom:1px solid var(--gray-200);box-shadow:var(--shadow-sm);}
.logo{display:flex;align-items:center;gap:14px;text-decoration:none;color:var(--navy-800);
      font-size:1.5rem;font-weight:700;letter-spacing:-0.02em;flex-shrink:0;}
.logo-circle{width:56px;height:56px;border-radius:50%;overflow:hidden;display:flex;
             align-items:center;justify-content:center;background:var(--navy-50);
             box-shadow:0 0 0 2.5px var(--navy-500),0 4px 12px rgba(10,25,49,0.15);flex-shrink:0;}
.logo-circle img{width:100%;height:100%;object-fit:cover;}
.logo-text em{font-style:normal;font-weight:400;color:var(--gray-500);}
.nav-links{display:flex;gap:0.35rem;align-items:center;flex-wrap:wrap;}
.nav-links a{color:var(--gray-600);text-decoration:none;padding:0.5rem 0.95rem;
             border-radius:var(--radius-sm);font-weight:500;font-size:0.88rem;
             transition:all 0.15s;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}
.nav-links a:hover{background:var(--navy-50);color:var(--navy-800);}
.nav-links a.active{background:var(--navy-700);color:var(--white);}
.nav-links a.logout{color:var(--crimson);}
.nav-links a.logout:hover{background:var(--crimson-bg);}
.mobile-toggle{display:none;background:none;border:none;color:var(--navy-800);
               font-size:1.4rem;cursor:pointer;padding:0.4rem;}

.container{max-width:840px;margin:0 auto;padding:2rem 5vw 3rem;}

/* ============================================================
   HUD — Hearts, Timer, Progress, Points
   ============================================================ */
.hud{
    background:var(--gradient-header);color:var(--white);
    border-radius:var(--radius-xl);padding:1.25rem 1.5rem;
    margin-bottom:1.5rem;position:relative;overflow:hidden;
    box-shadow:var(--shadow-lg);
}
.hud::before{
    content:'';position:absolute;inset:0;
    background:
        radial-gradient(circle at 10% 20%, rgba(82,183,136,0.25), transparent 55%),
        radial-gradient(circle at 90% 80%, rgba(82,183,136,0.15), transparent 50%);
    pointer-events:none;
}
.hud > *{position:relative;z-index:1;}
.hud-top{
    display:flex;justify-content:space-between;align-items:center;
    gap:1rem;flex-wrap:wrap;margin-bottom:1rem;
}
.hud-lives{display:flex;gap:6px;align-items:center;}
.hud-lives .label{
    font-size:0.72rem;text-transform:uppercase;letter-spacing:0.06em;
    font-weight:800;opacity:0.7;margin-right:6px;
}
.heart{
    font-size:1.5rem;color:#FF5252;
    filter:drop-shadow(0 2px 6px rgba(255,82,82,0.5));
    transition:all 0.3s ease;
}
.heart.lost{
    color:rgba(255,255,255,0.2);
    filter:none;
    transform:scale(0.85);
}
.heart.pulse{animation:heartPulse 0.6s ease;}
@keyframes heartPulse{
    0%{transform:scale(1);}
    50%{transform:scale(1.4);}
    100%{transform:scale(1);}
}

.hud-points{
    display:inline-flex;align-items:center;gap:8px;
    background:rgba(255,255,255,0.15);
    padding:8px 16px;border-radius:var(--radius-pill);
    border:1px solid rgba(255,255,255,0.25);
    backdrop-filter:blur(6px);
    font-weight:800;font-size:1.05rem;
}
.hud-points i{color:#FFD700;}

.hud-bottom{
    display:flex;justify-content:space-between;align-items:center;
    gap:1rem;flex-wrap:wrap;
}
.hud-progress-wrap{flex:1;min-width:200px;}
.hud-progress-label{
    display:flex;justify-content:space-between;align-items:center;
    font-size:0.78rem;font-weight:700;
    letter-spacing:0.03em;margin-bottom:6px;
}
.hud-progress-track{
    height:8px;background:rgba(255,255,255,0.15);
    border-radius:var(--radius-pill);overflow:hidden;
}
.hud-progress-fill{
    height:100%;width:0;
    background:linear-gradient(90deg,#95D5B2,#52B788);
    border-radius:var(--radius-pill);
    transition:width 0.5s cubic-bezier(0.4,0,0.2,1);
    box-shadow:0 0 12px rgba(82,183,136,0.6);
}

/* Timer ring */
.timer-wrap{
    position:relative;width:70px;height:70px;flex-shrink:0;
}
.timer-svg{transform:rotate(-90deg);width:70px;height:70px;}
.timer-bg{fill:none;stroke:rgba(255,255,255,0.15);stroke-width:5;}
.timer-fg{
    fill:none;stroke:#52B788;stroke-width:5;stroke-linecap:round;
    transition:stroke-dashoffset 0.9s linear, stroke 0.3s;
}
.timer-fg.warning{stroke:#FFA726;}
.timer-fg.danger{stroke:#FF5252;animation:timerPulse 0.8s infinite;}
@keyframes timerPulse{
    0%,100%{filter:drop-shadow(0 0 0 rgba(255,82,82,0));}
    50%{filter:drop-shadow(0 0 8px rgba(255,82,82,0.8));}
}
.timer-num{
    position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
    font-size:1.3rem;font-weight:800;color:var(--white);
    text-shadow:0 2px 6px rgba(0,0,0,0.3);
}

/* Relief goods indicator */
.relief-strip{
    display:flex;justify-content:space-between;align-items:center;
    background:var(--forest-100);border:1.5px solid var(--forest-400);
    border-radius:var(--radius-lg);padding:0.85rem 1.25rem;
    margin-bottom:1.5rem;
}
.relief-info{
    display:flex;align-items:center;gap:12px;
}
.relief-icon{
    width:42px;height:42px;border-radius:50%;
    background:var(--gradient-accent);color:var(--white);
    display:flex;align-items:center;justify-content:center;
    font-size:1.2rem;flex-shrink:0;
    box-shadow:0 6px 16px -4px rgba(64,145,108,0.5);
}
.relief-text h4{
    font-size:0.92rem;font-weight:700;color:var(--forest-900);margin-bottom:1px;
}
.relief-text p{
    font-size:0.78rem;color:var(--gray-600);
}
.relief-badge{
    display:inline-flex;align-items:center;gap:6px;
    padding:6px 14px;background:var(--white);
    border-radius:var(--radius-pill);
    font-weight:800;font-size:1rem;color:var(--forest-800);
    box-shadow:0 2px 8px rgba(64,145,108,0.15);
}
.relief-badge .num{color:var(--forest-700);font-size:1.25rem;}

/* ============================================================
   QUESTION STAGE
   ============================================================ */
.stage{
    background:var(--white);border:1px solid var(--gray-200);
    border-radius:var(--radius-xl);padding:2rem;
    box-shadow:var(--shadow-md);
    position:relative;overflow:hidden;
    animation:stageSlide 0.4s cubic-bezier(0.16,1,0.3,1);
}
@keyframes stageSlide{
    from{opacity:0;transform:translateY(20px);}
    to{opacity:1;transform:translateY(0);}
}
.stage::before{
    content:'';position:absolute;top:0;left:0;right:0;height:4px;
    background:var(--gradient-header);
    border-radius:var(--radius-xl) var(--radius-xl) 0 0;
}

.q-badge-row{
    display:flex;justify-content:space-between;align-items:center;
    flex-wrap:wrap;gap:0.6rem;margin-bottom:1rem;
}
.q-counter{
    display:inline-flex;align-items:center;gap:8px;
    font-size:0.82rem;font-weight:700;color:var(--navy-800);
}
.q-counter .num{
    background:var(--navy-700);color:var(--white);
    width:30px;height:30px;border-radius:50%;
    display:inline-flex;align-items:center;justify-content:center;
    font-size:0.78rem;font-weight:800;
}

.chip-row{display:flex;gap:6px;flex-wrap:wrap;}
.chip{
    display:inline-flex;align-items:center;gap:5px;
    padding:4px 11px;border-radius:var(--radius-pill);
    font-size:0.7rem;font-weight:700;
    text-transform:uppercase;letter-spacing:0.04em;
}
.chip.cat{background:var(--navy-50);color:var(--navy-700);}
.chip.pts{background:var(--yellow-bg);color:#B8860B;}
.chip i{font-size:0.7rem;}

.q-text{
    font-size:1.15rem;font-weight:700;color:var(--navy-900);
    line-height:1.45;margin:1rem 0 1.5rem;letter-spacing:-0.01em;
}

.options{display:flex;flex-direction:column;gap:0.6rem;}
.option{
    display:flex;align-items:center;gap:14px;
    padding:1rem 1.25rem;background:var(--gray-50);
    border:2px solid var(--gray-200);border-radius:var(--radius-md);
    cursor:pointer;font-family:inherit;font-size:0.95rem;
    color:var(--navy-900);text-align:left;font-weight:500;
    transition:all 0.2s ease;position:relative;
}
.option:hover:not(:disabled){
    background:var(--navy-50);border-color:var(--navy-300);
    transform:translateX(4px);
}
.option:disabled{cursor:not-allowed;}
.option .letter{
    display:inline-flex;align-items:center;justify-content:center;
    width:34px;height:34px;border-radius:50%;
    background:var(--white);border:2px solid var(--gray-300);
    color:var(--gray-600);font-weight:800;font-size:0.85rem;
    flex-shrink:0;transition:all 0.2s;
}
.option.correct{
    background:var(--status-bg)!important;border-color:var(--status-green)!important;
    color:var(--status-green)!important;font-weight:700;
    animation:popCorrect 0.5s ease;
}
.option.correct .letter{
    background:var(--status-green);border-color:var(--status-green);color:var(--white);
}
@keyframes popCorrect{
    0%{transform:scale(1);}
    50%{transform:scale(1.03);box-shadow:0 0 20px rgba(46,125,50,0.3);}
    100%{transform:scale(1);}
}
.option.wrong{
    background:var(--crimson-bg)!important;border-color:var(--crimson)!important;
    color:var(--crimson)!important;font-weight:700;
    animation:shakeWrong 0.4s ease;
}
.option.wrong .letter{
    background:var(--crimson);border-color:var(--crimson);color:var(--white);
}
@keyframes shakeWrong{
    0%,100%{transform:translateX(0);}
    25%{transform:translateX(-8px);}
    75%{transform:translateX(8px);}
}
.option.dimmed{opacity:0.4;}

/* Floating points gained */
.points-float{
    position:fixed;
    font-size:1.6rem;font-weight:800;color:var(--status-green);
    pointer-events:none;z-index:9999;
    animation:floatUpFade 1.2s ease-out forwards;
    text-shadow:0 4px 12px rgba(46,125,50,0.4);
}
@keyframes floatUpFade{
    0%{opacity:0;transform:translateY(0) scale(0.5);}
    20%{opacity:1;transform:translateY(-10px) scale(1.2);}
    100%{opacity:0;transform:translateY(-80px) scale(1);}
}

/* ============================================================
   GAME OVER SCREEN
   ============================================================ */
.gameover{
    background:var(--gradient-header);color:var(--white);
    border-radius:var(--radius-xl);padding:3rem 2rem;
    text-align:center;position:relative;overflow:hidden;
    box-shadow:var(--shadow-xl);display:none;
    animation:popIn 0.6s cubic-bezier(0.16,1,0.3,1);
}
.gameover.show{display:block;}
@keyframes popIn{
    from{opacity:0;transform:scale(0.92);}
    to{opacity:1;transform:scale(1);}
}
.gameover::before{
    content:'';position:absolute;inset:0;
    background:radial-gradient(circle at 50% 30%,rgba(82,183,136,0.35),transparent 60%);
    pointer-events:none;
}
.gameover > *{position:relative;z-index:1;}
.gameover .emoji{
    font-size:4.5rem;margin-bottom:0.75rem;
    animation:bounceSoft 1.4s infinite;
}
@keyframes bounceSoft{
    0%,100%{transform:translateY(0);}
    50%{transform:translateY(-12px);}
}
.gameover h2{
    font-size:1.9rem;font-weight:800;
    letter-spacing:-0.02em;margin-bottom:0.5rem;
}
.gameover .subtitle{
    opacity:0.85;font-size:1rem;margin-bottom:1.75rem;
}

/* Result stats */
.result-stats{
    display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));
    gap:1rem;margin:1.75rem 0;max-width:520px;margin-left:auto;margin-right:auto;
}
.result-stat{
    background:rgba(255,255,255,0.12);
    border:1px solid rgba(255,255,255,0.2);
    border-radius:var(--radius-lg);
    padding:1rem 0.75rem;backdrop-filter:blur(6px);
}
.result-stat .num{
    font-size:1.8rem;font-weight:800;letter-spacing:-0.03em;line-height:1.1;
}
.result-stat .lbl{
    font-size:0.7rem;text-transform:uppercase;
    letter-spacing:0.06em;opacity:0.8;margin-top:4px;font-weight:700;
}

/* Relief goods callout */
.relief-callout{
    background:rgba(82,183,136,0.18);
    border:1.5px solid rgba(82,183,136,0.4);
    border-radius:var(--radius-lg);
    padding:1.25rem 1.5rem;margin:1.5rem 0;
    display:flex;align-items:center;gap:1rem;
    flex-wrap:wrap;justify-content:center;
    max-width:520px;margin-left:auto;margin-right:auto;
}
.relief-callout .big-icon{
    width:56px;height:56px;border-radius:50%;
    background:var(--gradient-accent);color:var(--white);
    display:flex;align-items:center;justify-content:center;
    font-size:1.6rem;flex-shrink:0;
    box-shadow:0 8px 24px -6px rgba(82,183,136,0.6);
}
.relief-callout .info{text-align:left;}
.relief-callout .info h3{
    font-size:1.2rem;font-weight:800;margin-bottom:2px;
}
.relief-callout .info p{
    font-size:0.85rem;opacity:0.85;
}

.result-actions{
    display:flex;gap:0.75rem;justify-content:center;flex-wrap:wrap;
    margin-top:1.75rem;
}
.result-actions .btn{
    padding:0.85rem 1.7rem;border-radius:var(--radius-sm);
    font-family:inherit;font-size:0.95rem;font-weight:700;
    cursor:pointer;text-decoration:none;
    display:inline-flex;align-items:center;gap:8px;
    transition:all 0.15s;border:none;
}
.result-actions .btn-primary{
    background:var(--white);color:var(--navy-800);
    box-shadow:0 6px 20px rgba(0,0,0,0.15);
}
.result-actions .btn-primary:hover{
    background:var(--gray-100);transform:translateY(-2px);
    box-shadow:0 10px 26px rgba(0,0,0,0.2);
}
.result-actions .btn-outline{
    background:rgba(255,255,255,0.15);color:var(--white);
    border:1.5px solid rgba(255,255,255,0.35);
}
.result-actions .btn-outline:hover{
    background:rgba(255,255,255,0.25);border-color:var(--white);
}

/* Start screen */
.start-screen{
    background:var(--white);border:1px solid var(--gray-200);
    border-radius:var(--radius-xl);padding:3rem 2rem;
    text-align:center;box-shadow:var(--shadow-lg);
    position:relative;overflow:hidden;
}
.start-screen::before{
    content:'';position:absolute;top:0;left:0;right:0;height:5px;
    background:var(--gradient-header);
}
.start-screen .big-emoji{
    font-size:4.5rem;margin-bottom:1rem;
    animation:bounceSoft 1.4s infinite;
}
.start-screen h2{
    font-size:1.75rem;font-weight:800;
    color:var(--navy-900);letter-spacing:-0.02em;margin-bottom:0.5rem;
}
.start-screen p{
    color:var(--gray-500);font-size:0.98rem;
    margin-bottom:2rem;max-width:520px;margin-left:auto;margin-right:auto;
}

.rules{
    display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:1rem;max-width:600px;margin:0 auto 2rem;
}
.rule{
    background:var(--gray-50);border:1px solid var(--gray-200);
    border-radius:var(--radius-lg);padding:1.25rem 1rem;
    transition:all 0.2s;
}
.rule:hover{
    transform:translateY(-3px);box-shadow:var(--shadow-md);
    border-color:var(--forest-400);
}
.rule i{
    font-size:1.6rem;color:var(--forest-700);margin-bottom:0.5rem;display:block;
}
.rule h4{
    font-size:0.9rem;font-weight:700;color:var(--navy-900);margin-bottom:3px;
}
.rule p{
    font-size:0.78rem;color:var(--gray-500);margin:0;line-height:1.45;
}

.btn-start{
    padding:0.95rem 2.5rem;background:var(--gradient-accent);
    color:var(--white);border:none;border-radius:var(--radius-sm);
    font-family:inherit;font-size:1rem;font-weight:700;
    cursor:pointer;display:inline-flex;align-items:center;gap:10px;
    transition:all 0.15s;
    box-shadow:0 8px 24px -6px rgba(64,145,108,0.6);
    letter-spacing:0.02em;
}
.btn-start:hover{
    transform:translateY(-3px);
    box-shadow:0 14px 32px -6px rgba(64,145,108,0.7);
}
.btn-start:active{transform:translateY(-1px);}

/* Empty */
.empty{
    background:var(--white);border:2px dashed var(--navy-300);
    border-radius:var(--radius-xl);padding:3rem 1.5rem;text-align:center;
    color:var(--gray-500);box-shadow:var(--shadow-sm);
}
.empty i{font-size:3rem;color:var(--gray-300);display:block;margin-bottom:0.75rem;}
.empty h3{color:var(--navy-800);font-weight:700;margin-bottom:0.4rem;}
.empty p{font-size:0.92rem;}

/* FOOTER */
footer{background:var(--navy-900);color:rgba(255,255,255,0.75);
       text-align:center;padding:1.75rem 5vw;border-top:3px solid var(--forest-700);
       margin-top:2rem;}
footer p{font-size:0.88rem;}
footer p.sub{opacity:0.6;font-size:0.8rem;margin-top:0.3rem;}

/* RESPONSIVE */
@media (max-width:768px){
    body{padding-top:76px;}
    .navbar{padding:0.6rem 1.25rem;flex-wrap:wrap;}
    .mobile-toggle{display:block;}
    .nav-links{display:none;width:100%;flex-direction:column;align-items:stretch;
               padding:0.75rem 0 0.25rem;border-top:1px solid var(--gray-200);margin-top:0.5rem;}
    .nav-links.active{display:flex;}
    .nav-links a{padding:0.7rem 1rem;}
    .logo{font-size:1.2rem;gap:10px;}
    .logo-circle{width:48px;height:48px;}
    .logo-text em{display:none;}
    .container{padding:1.5rem 1.25rem 2.5rem;}
    .stage{padding:1.5rem 1.25rem;}
    .hud{padding:1rem 1.1rem;}
    .hud-top{flex-direction:column;align-items:flex-start;}
    .timer-wrap{width:60px;height:60px;}
    .timer-svg{width:60px;height:60px;}
    .timer-num{font-size:1.1rem;}
    .q-text{font-size:1.05rem;}
    .option{padding:0.85rem 1rem;font-size:0.9rem;}
    .start-screen{padding:2rem 1.25rem;}
    .start-screen .big-emoji{font-size:3.5rem;}
    .gameover{padding:2rem 1.25rem;}
    .gameover .emoji{font-size:3.5rem;}
    .gameover h2{font-size:1.45rem;}
    .result-stat .num{font-size:1.5rem;}
    .relief-strip{flex-direction:column;gap:0.85rem;text-align:center;}
    .relief-info{flex-direction:column;gap:8px;}
}
:focus-visible{outline:2px solid var(--navy-600);outline-offset:2px;}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <a href="../dashboard.php" class="logo">
        <div class="logo-circle">
            <img src="../logo.png" alt="Logo"
                 onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\'fas fa-leaf\' style=\'color:var(--forest-700);font-size:1.5rem;\'></i>';">
        </div>
        <div class="logo-text">Smart<em>EcoTrack</em></div>
    </a>
    <button class="mobile-toggle" onclick="toggleMenu()" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>
    <div class="nav-links" id="navbarNav">
        <a href="../dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="disaster_tips.php"><i class="fas fa-shield-alt"></i> Tips</a>
        <a href="quiz.php" class="active"><i class="fas fa-gamepad"></i> Quiz</a>
        <a href="emergency_contacts.php"><i class="fas fa-phone-alt"></i> Emergency</a>
        <a href="../profile.php"><i class="fas fa-user-circle"></i> Profile</a>
        <a href="../logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</nav>

<div class="container">

    <?php if ($totalQuestions === 0): ?>
        <!-- Empty state -->
        <div class="empty">
            <i class="fas fa-circle-question"></i>
            <h3>No quiz questions available</h3>
            <p>Ask the admin to add questions to the <code>quiz_questions</code> table.</p>
        </div>
    <?php else: ?>

        <!-- ============================================================
             START SCREEN
             ============================================================ -->
        <div class="start-screen" id="startScreen">
            <div class="big-emoji">🎮</div>
            <h2>Disaster Preparedness Challenge</h2>
            <p>Answer fast, stay alive, earn points — and convert them to relief goods for your community.</p>

            <div class="rules">
                <div class="rule">
                    <i class="fas fa-question-circle"></i>
                    <h4><?= $totalQuestions ?> Questions</h4>
                    <p>Unique — no repeats</p>
                </div>
                <div class="rule">
                    <i class="fas fa-clock"></i>
                    <h4>20 Seconds</h4>
                    <p>Per question timer</p>
                </div>
                <div class="rule">
                    <i class="fas fa-heart"></i>
                    <h4>3 Lives</h4>
                    <p>Lose one per wrong answer</p>
                </div>
                <div class="rule">
                    <i class="fas fa-gift"></i>
                    <h4>100 pts = 1 Good</h4>
                    <p>Convert to relief goods</p>
                </div>
            </div>

            <button type="button" class="btn-start" onclick="startGame()">
                <i class="fas fa-play"></i> Start Quiz
            </button>
        </div>

        <!-- ============================================================
             HUD + GAME AREA (hidden until start)
             ============================================================ -->
        <div id="gameArea" style="display:none;">

            <!-- HUD -->
            <div class="hud">
                <div class="hud-top">
                    <div class="hud-lives">
                        <span class="label">Lives</span>
                        <span class="heart" id="heart1">❤️</span>
                        <span class="heart" id="heart2">❤️</span>
                        <span class="heart" id="heart3">❤️</span>
                    </div>
                    <div class="hud-points">
                        <i class="fas fa-star"></i>
                        <span id="pointsDisplay">0</span> pts
                    </div>
                </div>

                <div class="hud-bottom">
                    <div class="hud-progress-wrap">
                        <div class="hud-progress-label">
                            <span>Progress</span>
                            <span><span id="qCurrent">1</span> / <?= $totalQuestions ?></span>
                        </div>
                        <div class="hud-progress-track">
                            <div class="hud-progress-fill" id="hudProgress"></div>
                        </div>
                    </div>

                    <div class="timer-wrap">
                        <svg class="timer-svg" viewBox="0 0 70 70">
                            <circle class="timer-bg" cx="35" cy="35" r="30"></circle>
                            <circle class="timer-fg" id="timerFg" cx="35" cy="35" r="30"
                                    stroke-dasharray="188.5"
                                    stroke-dashoffset="0"></circle>
                        </svg>
                        <div class="timer-num" id="timerNum">20</div>
                    </div>
                </div>
            </div>

            <!-- Relief goods strip -->
            <div class="relief-strip">
                <div class="relief-info">
                    <div class="relief-icon"><i class="fas fa-box-open"></i></div>
                    <div class="relief-text">
                        <h4>Relief Goods Vouchers</h4>
                        <p>Every 100 points = 1 relief good</p>
                    </div>
                </div>
                <div class="relief-badge">
                    <span class="num" id="reliefCount">0</span>
                    <span>goods</span>
                </div>
            </div>

            <!-- Question stage -->
            <div class="stage" id="stage">
                <div class="q-badge-row">
                    <div class="q-counter">
                        <span class="num" id="qNum">1</span>
                        <span>of <?= $totalQuestions ?></span>
                    </div>
                    <div class="chip-row">
                        <span class="chip cat" id="qCat"><i class="fas fa-tag"></i> General</span>
                        <span class="chip pts" id="qPts"><i class="fas fa-star"></i> 0 pts</span>
                    </div>
                </div>

                <h2 class="q-text" id="qText">Loading…</h2>

                <div class="options" id="optionsWrap"></div>
            </div>

        </div>

        <!-- ============================================================
             GAME OVER SCREEN
             ============================================================ -->
        <div class="gameover" id="gameOver">
            <div class="emoji" id="goEmoji">🎉</div>
            <h2 id="goTitle">Quiz Complete!</h2>
            <p class="subtitle" id="goMsg">Great job — you're more prepared than before.</p>

            <div class="result-stats">
                <div class="result-stat">
                    <div class="num" id="goCorrect">0</div>
                    <div class="lbl">Correct</div>
                </div>
                <div class="result-stat">
                    <div class="num" id="goPoints">0</div>
                    <div class="lbl">Points</div>
                </div>
                <div class="result-stat">
                    <div class="num" id="goAccuracy">0%</div>
                    <div class="lbl">Accuracy</div>
                </div>
            </div>

            <div class="relief-callout">
                <div class="big-icon"><i class="fas fa-box-open"></i></div>
                <div class="info">
                    <h3 id="goReliefTitle">You earned 1 relief good!</h3>
                    <p>Thanks for helping your community stay prepared.</p>
                </div>
            </div>

            <div class="result-actions">
                <button type="button" class="btn btn-primary" onclick="restartQuiz()">
                    <i class="fas fa-rotate-right"></i> Try Again
                </button>
                <a href="../dashboard.php" class="btn btn-outline">
                    <i class="fas fa-home"></i> Back to Dashboard
                </a>
            </div>
        </div>

    <?php endif; ?>

</div>

<footer>
    <p>&copy; <?= date('Y') ?> SmartEcoTrack · Environmental Incident Reporting & Monitoring System</p>
    <p class="sub">Working together for a safer, greener Philippines 🌿</p>
</footer>

<script>
    /* ---------- Mobile menu ---------- */
    function toggleMenu() {
        document.getElementById('navbarNav').classList.toggle('active');
    }
    document.addEventListener('click', function(e) {
        const nav = document.getElementById('navbarNav');
        const toggle = document.querySelector('.mobile-toggle');
        if (nav.classList.contains('active') &&
            !nav.contains(e.target) && !toggle.contains(e.target)) {
            nav.classList.remove('active');
        }
    });

    /* ============================================================
       QUIZ ENGINE
       ============================================================ */
    const QUESTIONS = <?= json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const TOTAL          = QUESTIONS.length;
    const MAX_LIVES      = 3;
    const TIME_PER_Q     = 20;            // seconds
    const PTS_PER_GOOD   = 100;           // 100 pts = 1 relief good
    const TIME_BONUS_MAX = 5;             // max bonus points per question
    const TIMER_CIRC     = 188.5;         // circumference of the SVG ring

    /* ---------- State ---------- */
    let currentIndex = 0;
    let lives        = MAX_LIVES;
    let points       = 0;
    let correctCount = 0;
    let answered     = 0;
    let timeLeft     = TIME_PER_Q;
    let timerId      = null;
    let locked       = false;
    let gameActive   = false;

    /* ---------- Elements ---------- */
    const startScreen = document.getElementById('startScreen');
    const gameArea    = document.getElementById('gameArea');
    const gameOver    = document.getElementById('gameOver');

    const qTextEl    = document.getElementById('qText');
    const optionsEl  = document.getElementById('optionsWrap');
    const qNumEl     = document.getElementById('qNum');
    const qCatEl     = document.getElementById('qCat');
    const qPtsEl     = document.getElementById('qPts');
    const qCurrentEl = document.getElementById('qCurrent');

    const timerNum = document.getElementById('timerNum');
    const timerFg  = document.getElementById('timerFg');

    const pointsDisplay = document.getElementById('pointsDisplay');
    const reliefCount   = document.getElementById('reliefCount');
    const hudProgress   = document.getElementById('hudProgress');

    /* ============================================================
       START GAME
       ============================================================ */
    function startGame() {
        startScreen.style.display = 'none';
        gameArea.style.display = 'block';
        gameOver.classList.remove('show');

        currentIndex = 0;
        lives        = MAX_LIVES;
        points       = 0;
        correctCount = 0;
        answered     = 0;
        gameActive   = true;

        updateHUD();
        renderQuestion();
    }

    /* ============================================================
       RENDER CURRENT QUESTION
       ============================================================ */
    function renderQuestion() {
        if (currentIndex >= TOTAL) { endGame('win'); return; }

        locked = false;
        const q = QUESTIONS[currentIndex];

        /* Update counters */
        qNumEl.textContent     = currentIndex + 1;
        qCurrentEl.textContent = currentIndex + 1;
        qTextEl.textContent    = q.question;
        qCatEl.innerHTML       = '<i class="fas fa-tag"></i> ' + escapeHtml(q.category);
        qPtsEl.innerHTML       = '<i class="fas fa-star"></i> ' + q.points + ' pts';

        /* Build options */
        optionsEl.innerHTML = '';
        Object.keys(q.options).forEach(letter => {
            const btn = document.createElement('button');
            btn.type      = 'button';
            btn.className = 'option';
            btn.innerHTML =
                '<span class="letter">' + letter + '</span>' +
                '<span>' + escapeHtml(q.options[letter]) + '</span>';
            btn.dataset.letter = letter;
            btn.addEventListener('click', () => onAnswer(btn, letter, q));
            optionsEl.appendChild(btn);
        });

        /* Reset timer */
        timeLeft = TIME_PER_Q;
        updateTimerDisplay();
        startTimer();

        /* Animate the stage */
        const stage = document.getElementById('stage');
        stage.style.animation = 'none';
        void stage.offsetWidth;
        stage.style.animation = 'stageSlide 0.4s cubic-bezier(0.16,1,0.3,1)';
    }

    /* ============================================================
       TIMER
       ============================================================ */
    function startTimer() {
        clearInterval(timerId);
        timerId = setInterval(() => {
            timeLeft--;
            updateTimerDisplay();

            if (timeLeft <= 0) {
                clearInterval(timerId);
                if (!locked) onTimeout();
            }
        }, 1000);
    }

    function updateTimerDisplay() {
        timerNum.textContent = timeLeft;

        const ratio   = timeLeft / TIME_PER_Q;
        const dashOff = TIMER_CIRC * (1 - ratio);
        timerFg.style.strokeDashoffset = dashOff;

        /* Color feedback */
        timerFg.classList.remove('warning', 'danger');
        if (timeLeft <= 5)       timerFg.classList.add('danger');
        else if (timeLeft <= 10) timerFg.classList.add('warning');
    }

    /* ============================================================
       ANSWER HANDLING
       ============================================================ */
    function onAnswer(btn, letter, q) {
        if (locked) return;
        locked = true;
        clearInterval(timerId);

        const isCorrect = (letter === q.correct);
        const allOptions = optionsEl.querySelectorAll('.option');
        allOptions.forEach(o => o.disabled = true);

        if (isCorrect) {
            btn.classList.add('correct');

            /* Base points */
            let earned = q.points;

            /* Time bonus (max 5) */
            const timeBonus = Math.min(TIME_BONUS_MAX, Math.max(0, timeLeft));
            earned += timeBonus;

            points += earned;
            correctCount++;

            /* Float the points up */
            floatPoints(btn, '+' + earned);
            updateHUD();

        } else {
            btn.classList.add('wrong');
            /* Reveal correct answer */
            allOptions.forEach(o => {
                if (o.dataset.letter === q.correct) {
                    o.classList.add('correct');
                } else {
                    o.classList.add('dimmed');
                }
            });

            /* Lose a life */
            loseLife();
        }

        answered++;
        updateHUD();

        /* Next question after delay */
        setTimeout(() => {
            if (lives <= 0) { endGame('lose'); return; }
            currentIndex++;
            renderQuestion();
        }, isCorrect ? 900 : 1600);
    }

    function onTimeout() {
        if (locked) return;
        locked = true;

        const allOptions = optionsEl.querySelectorAll('.option');
        allOptions.forEach(o => {
            o.disabled = true;
            if (o.dataset.letter === QUESTIONS[currentIndex].correct) {
                o.classList.add('correct');
            } else {
                o.classList.add('dimmed');
            }
        });

        loseLife();
        answered++;
        updateHUD();

        setTimeout(() => {
            if (lives <= 0) { endGame('lose'); return; }
            currentIndex++;
            renderQuestion();
        }, 1600);
    }

    /* ============================================================
       LIVES
       ============================================================ */
    function loseLife() {
        lives = Math.max(0, lives - 1);

        /* Animate the lost heart */
        const heartId = 'heart' + (lives + 1);
        const heart = document.getElementById(heartId);
        if (heart) {
            heart.classList.add('lost', 'pulse');
            setTimeout(() => heart.classList.remove('pulse'), 700);
        }
    }

    /* ============================================================
       HUD UPDATE
       ============================================================ */
    function updateHUD() {
        pointsDisplay.textContent = points;
        reliefCount.textContent   = Math.floor(points / PTS_PER_GOOD);

        /* Progress bar = answered / total */
        const pct = TOTAL > 0 ? (answered / TOTAL) * 100 : 0;
        hudProgress.style.width = pct + '%';

        /* Update hearts */
        for (let i = 1; i <= MAX_LIVES; i++) {
            const h = document.getElementById('heart' + i);
            if (!h) continue;
            if (i > lives) h.classList.add('lost');
            else           h.classList.remove('lost');
        }
    }

    /* ============================================================
       FLOATING POINTS ANIMATION
       ============================================================ */
    function floatPoints(anchorEl, text) {
        const rect = anchorEl.getBoundingClientRect();
        const el = document.createElement('div');
        el.className = 'points-float';
        el.textContent = text;
        el.style.left = (rect.left + rect.width / 2) + 'px';
        el.style.top  = (rect.top + rect.height / 2) + 'px';
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 1200);
    }

    /* ============================================================
       END GAME
       ============================================================ */
    function endGame(reason) {
        gameActive = false;
        clearInterval(timerId);

        const goods = Math.floor(points / PTS_PER_GOOD);
        const pct   = TOTAL > 0 ? Math.round((correctCount / TOTAL) * 100) : 0;

        /* Header */
        let emoji, title, msg;
        if (reason === 'lose') {
            emoji = '💔';
            title = 'Out of Lives!';
            msg   = 'You ran out of hearts — but every attempt makes you stronger.';
        } else if (pct === 100) {
            emoji = '🏆';
            title = 'Perfect Score!';
            msg   = 'Flawless performance — you are a true disaster preparedness expert.';
        } else if (pct >= 75) {
            emoji = '🎉';
            title = 'Excellent!';
            msg   = 'Great work! You have strong knowledge of disaster safety.';
        } else if (pct >= 50) {
            emoji = '👍';
            title = 'Good Job!';
            msg   = 'Solid effort — review the guides to strengthen your skills.';
        } else {
            emoji = '📚';
            title = 'Keep Learning';
            msg   = 'Review our disaster preparedness guides and try again!';
        }

        document.getElementById('goEmoji').textContent   = emoji;
        document.getElementById('goTitle').textContent   = title;
        document.getElementById('goMsg').textContent     = msg;
        document.getElementById('goCorrect').textContent = correctCount;
        document.getElementById('goPoints').textContent  = points;
        document.getElementById('goAccuracy').textContent = pct + '%';

        /* Relief goods title */
        const reliefTitle = document.getElementById('goReliefTitle');
        if (goods === 0) {
            reliefTitle.textContent = 'Almost there — keep practicing!';
        } else if (goods === 1) {
            reliefTitle.textContent = 'You earned 1 relief good!';
        } else {
            reliefTitle.textContent = 'You earned ' + goods + ' relief goods!';
        }

        /* Show */
        gameArea.style.display = 'none';
        gameOver.classList.add('show');
        gameOver.scrollIntoView({ behavior: 'smooth', block: 'center' });

        /* Save score silently */
        saveScore(points, correctCount, TOTAL);
    }

    /* ============================================================
       SAVE SCORE
       ============================================================ */
    function saveScore(score, correct, total) {
        fetch('save_quiz_result.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'score='   + encodeURIComponent(score) +
                  '&correct=' + encodeURIComponent(correct) +
                  '&total='   + encodeURIComponent(total)
        }).catch(() => {});
    }

    /* ============================================================
       RESTART
       ============================================================ */
    function restartQuiz() {
        window.location.reload();
    }

    /* ============================================================
       UTIL
       ============================================================ */
    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }
</script>
</body>
</html>